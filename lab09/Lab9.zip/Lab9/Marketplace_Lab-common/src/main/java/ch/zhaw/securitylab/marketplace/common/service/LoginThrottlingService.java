package ch.zhaw.securitylab.marketplace.common.service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import ch.zhaw.securitylab.marketplace.common.facade.UserInfoFacade;
import jakarta.ejb.Singleton;
import jakarta.inject.Inject;

@Singleton
public class LoginThrottlingService implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final int BLOCKING_TIME = 60;
    private static final int BLOCKING_LIMIT = 3;

    @Inject
    private UserInfoFacade userInfoFacade;

    private Map<String, Integer> loginFailedCount = new HashMap<>();
    private Map<String, Long> loginBlockedUntil = new HashMap<>();

    /**
     * Is called to inform that the login with username has failed.
     *
     * @param username The username for which the login failed
     */
    public void loginFailed(String username) {
        // Implement
        if (userInfoFacade.findByUsername(username) == null) {
            return;
        }

        if (!loginFailedCount.containsKey(username)) {
            loginFailedCount.put(username, 0);
        }
        loginFailedCount.put(username, loginFailedCount.get(username) + 1);
        if (loginFailedCount.get(username) >= BLOCKING_LIMIT) {
            loginBlockedUntil.put(username, System.currentTimeMillis() / 1000 + BLOCKING_TIME);
        }

    }

    /**
     * Is called to inform that the login with username has succeeded.
     *
     * @param username The username for which the login succeeded
     */
    public void loginSuccessful(String username) {

        // Implement
        if (loginFailedCount.containsKey(username)) {
            loginFailedCount.remove(username);
        }
    }

    /**
     * Returns whether the user username is blocked.
     *
     * @param username The username to check
     * @return true if the user is blocked, false otherwise
     */
    public boolean isBlocked(String username) {

        // Implement
        if (
                loginBlockedUntil.containsKey(username)
                        && System.currentTimeMillis() / 1000 < loginBlockedUntil.get(username)
        ) {
            return true;
        }
        return false;
    }
}
