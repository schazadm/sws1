package ch.zhaw.securitylab.marketplace.rest.core;

import java.security.InvalidParameterException;
import java.util.List;

import ch.zhaw.securitylab.marketplace.common.facade.ProductFacade;
import ch.zhaw.securitylab.marketplace.common.service.AdminProductService;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.SecurityContext;
import ch.zhaw.securitylab.marketplace.common.model.AdminProductDto;
import ch.zhaw.securitylab.marketplace.common.model.Product;

@RequestScoped
@Path("admin/products")
public class AdminProductRest {

    @Inject
    private ProductFacade productFacade;

    @Inject
    private AdminProductService adminProductService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("productmanager")
    public List<AdminProductDto> get() {
        
        // Implement
        
        return productFacade.findAll().stream().map(AdminProductDto::new).toList();
    }

    @POST
    @RolesAllowed("productmanager")
    @Consumes(MediaType.APPLICATION_JSON)
    public void post(@Valid Product product, @Context SecurityContext context) {
        
        /* @Context injects the SecurityContext object of the current request 
           as a method parameter. SecurityContext is part of JAX-RS and provides
           security-relevant information such as the name of the user who sent 
           the request. Accessing this name can be done with 
           context.getUserPrincipal().getName() */
        
        // Implement
        product.setUsername(context.getUserPrincipal().getName());
        if(!adminProductService.insertProduct(product)) {
            throw new InvalidParameterException("The product could not be added as a product with the same code already exists. Please insert a valid code!");
        }

    }

    @DELETE
    @RolesAllowed("productmanager")
    @Path("{id}")
    public void delete(@PathParam("id")
                           @Min(value = 1, message = "The ProductID must be between 1 and 999'999")
                           @Max(value = 999999, message = "The ProductID must be between 1 and 999'999")
                           String id, @Context SecurityContext context) {
        
        // Implement
        Product product = productFacade.findById(Integer.parseInt(id));

        if(product == null) {
            throw new InvalidParameterException("The product with ProductID '"+id+"' does not exist!");
        }
        if(!product.getUsername().equals(context.getUserPrincipal().getName())) {
            throw new AuthorizationException("Access denied. only the own products can be deleted");
        }

        productFacade.remove(product);

    }
}
