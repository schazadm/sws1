package ch.zhaw.securitylab.marketplace.rest.core;

import ch.zhaw.securitylab.marketplace.common.model.RestErrorDto;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

import java.util.Set;

@Provider
public class AuthorizationExceptionMapper implements ExceptionMapper<AuthorizationException> {

    @Override
    public Response toResponse(AuthorizationException exception) {
        RestErrorDto error = new RestErrorDto();
        error.setError(exception.getMessage());
        return Response.status(Response.Status.FORBIDDEN).entity(error).build();
    }
}
