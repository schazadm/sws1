package ch.zhaw.securitylab.marketplace.web.backing;

import ch.zhaw.securitylab.marketplace.common.facade.UserInfoFacade;
import ch.zhaw.securitylab.marketplace.common.model.UserInfo;
import ch.zhaw.securitylab.marketplace.common.service.AccountSettingsService;

import jakarta.inject.Named;
import jakarta.security.enterprise.identitystore.Pbkdf2PasswordHash;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.faces.context.FacesContext;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.validation.constraints.Size;
import ch.zhaw.securitylab.marketplace.common.utility.Message;

import java.util.HashMap;
import java.util.Map;

@Named
@RequestScoped
public class AccountSettingsBacking {

    @Inject
    private AccountSettingsService accountSettingsService;

    @Inject
    private UserInfoFacade userFacade;

    @Inject
    private Pbkdf2PasswordHash pbkdf2PasswordHash;


    @Size(min=4, message = "Please insert a new password with at least 4 characters")
    private String newPassword;

    private String existingPassword;

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getExistingPassword() {
        return existingPassword;
    }

    public void setExistingPassword(String existingPassword) {
        this.existingPassword = existingPassword;
    }

    public String changePassword() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();


        System.out.println(existingPassword);
        if (accountSettingsService.changePassword(request.getRemoteUser(), newPassword, existingPassword)) {

            Message.setMessage("Your password was successfully changed");
            return "/view/admin/admin";
        } else {
            Message.setMessage("The password could not be changed");
            return "/view/admin/account/accountsettings";
        }
    }
}
