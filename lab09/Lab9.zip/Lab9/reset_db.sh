#!/bin/zsh

mysql -uroot -ppassword -e "drop database marketplace; create database marketplace;"
mysql -uroot -ppassword marketplace < ./Marketplace.sql
mysql -uroot -ppassword marketplace < ./Marketplace_UpdateEncryptedCreditCards.sql
